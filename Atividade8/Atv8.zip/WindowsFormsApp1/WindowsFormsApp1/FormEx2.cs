﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormEx2 : Form
    {
        public FormEx2()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int tam = richTextBox1.Text.Length;
            int cont=0;
            for (int i = 0; i < tam; i++)
            {
                if (richTextBox1.Text[i] == ' ')
                {
                    cont++;
                }
            }
            if (cont == 1)
                MessageBox.Show("Há " + cont + " espaço");
            else
                MessageBox.Show("Há " + cont + " espaços");
        }
            private void btnR_Click(object sender, EventArgs e)
            {
            int tam = richTextBox1.Text.Length;
            int cont = 0;
            int x = 0;
            while (x < tam)
            {
                if (richTextBox1.Text[x] == 'R')
                {
                    cont++;
                }
                x++;
            }
            if (cont==1)
                MessageBox.Show("Há "+cont+" R");
            else
                MessageBox.Show("Há " + cont + " Rs");
        }

            private void btnDuplo_Click(object sender, EventArgs e)
            {
            char lastChar = '\0'; 
            int cont = 0;
            foreach (char c in richTextBox1.Text)
            {
                if (c == lastChar)
                {
                    cont++;
                }
                else
                {
                    if (lastChar != '\0')
                    {
                        Console.WriteLine($"Letra: {lastChar}, Quantidade: {cont}");
                    }
                   
                    cont = 1;
                    lastChar = c;
                }
            }

            // Exibe o resultado para a última letra
            if (lastChar != '\0')
            {
                Console.WriteLine($"Letra: {lastChar}, Quantidade: {cont}");
            }
        }
        }
    }

