﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormEx1 : Form
    {
        public FormEx1()
        {
            InitializeComponent();
        }

        private void btnTeste_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 50)
            {
                textBox1.Text = textBox1.Text.ToLower();
                string novaString = "";
                for (int i = 0; i < textBox1.Text.Length; i++)
                {
                    if (textBox1.Text[i] != ' ')
                    {
                        novaString += textBox1.Text[i];
                    }
                }
                textBox1.Text = novaString;
                char[] vet = textBox1.Text.ToCharArray();
                Array.Reverse(vet);
                string reversedText = new string(vet);

                if (reversedText == textBox1.Text)
                {
                    MessageBox.Show("A string é um palíndromo.");
                }
                else
                {
                    MessageBox.Show("A string não é um palíndromo.");
                }
            }
            else
                MessageBox.Show("Deve ser menor que 50");
        }
    }
}
