﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class FormEx3 : Form
    {
        public FormEx3()
        {
            InitializeComponent();
        }
        private int num = 0;

        private void textBox1_Keypress(object sender, KeyPressEventArgs e)
{
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                
                
                    e.Handled = true;
                
            }

            int.TryParse(textBox1.Text + e.KeyChar, out int tempNum);

    if (tempNum == 0)
    {
        e.Handled = true;
    }
    else
    {
        num = tempNum;
    }
}

private void btnGerar_Click(object sender, EventArgs e)
{
            double h=0;
    if (num != 0)
    {
        for (int i = 1; i <= num; i++)
        {
                    h += 1.0 / i;
        }
                MessageBox.Show("H ="+h);
            }
    
}
    }
}
