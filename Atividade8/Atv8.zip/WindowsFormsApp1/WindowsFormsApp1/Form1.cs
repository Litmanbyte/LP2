﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }
        

        private void ex4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx4>().Count() > 0)
            {

                Application.OpenForms["FormEx4"].BringToFront();
            }
            else
            {
                FormEx4 obj4 = new FormEx4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();

            }
        }
    

        private void ex3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx3>().Count() > 0)
            {

                Application.OpenForms["FormEx3"].BringToFront();
            }
            else
            {
                FormEx3 obj3 = new FormEx3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();

            }
        }


        private void ex2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx2>().Count() > 0)
            {

                Application.OpenForms["FormEx2"].BringToFront();
            }
            else
            {
                FormEx2 obj2 = new FormEx2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();

            }
        }


        private void ex1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormEx1>().Count() > 0)
            {

                Application.OpenForms["FormEx1"].BringToFront();
            }
            else
            {
                FormEx1 obj1 = new FormEx1();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();

            }
        }
    }
}
