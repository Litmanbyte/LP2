﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormEx4 : Form
    {
        public FormEx4()
        {
            InitializeComponent();
        }
        private void txtN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != ' ' && e.KeyChar != '\b')
            {
                e.Handled = true; 
            }
        }
        private void btnCalc_Click(object sender, EventArgs e)
        {
            double num, bruto, g;
            int numero, b = 0, c = 0, d = 0;

            // Validar entrada txtG
            if (!double.TryParse(txtG.Text, out g))
            {
                MessageBox.Show("Digite um número válido para gratificação.");
                return;
            }

            // Validar entrada txtP
            if (!int.TryParse(txtP.Text, out numero))
            {
                MessageBox.Show("Digite um número inteiro válido para produção.");
                return;
            }

            // Validar intervalo para 'numero'
            if (numero < 0)
            {
                MessageBox.Show("não há produção negativa");
                return;
            }

            if (numero >= 100) { b = 1; }
            if (numero >= 120) { c = 1; }
            if (numero >= 150) { d = 1; }

            // Validar entrada txtS
            if (!double.TryParse(txtS.Text, out num))
            {
                MessageBox.Show("Digite um valor valido para o salário.");
                return;
            }

            bruto = num + (num * (b * 0.05 + 0.1 * c + 0.1 * d)) + g;

            // Validar resultado bruto
            if (bruto > 7000)
            {
                if (numero >= 150 && g > 0)
                    MessageBox.Show("Seu salário bruto é :" + bruto);
                else
                    MessageBox.Show("Seu salário bruto é :7000");
            }
            else
                MessageBox.Show("Seu salário bruto é :" + bruto);
        }
    }
}
