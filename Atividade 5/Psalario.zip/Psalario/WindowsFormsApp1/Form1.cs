﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnVal_Click(object sender, EventArgs e)
        {
            double l=0,vlrSalL, vlrSal, descA = 0, descB = 0,filho;
            if (!double.TryParse(mskbxSal.Text, out vlrSal))
            {
                MessageBox.Show("Valores invalidos");
                mskbxSal.Focus();
            }
            else if (vlrSal <= 0)
            {
                MessageBox.Show("Valores invalidos");
                mskbxSal.Focus();
            }
           

            else
            {
                if (vlrSal < 800.47)
                {
                    descA = 0.0765 * vlrSal;
                    txtAinss.Text = "7,65%";
                    txtDinss.Text = descA.ToString();
                }
                if (vlrSal > 800.47 && vlrSal < 1050)
                {
                    descA = 0.0865 * vlrSal;
                    txtAinss.Text = "8,65%";
                    txtDinss.Text = descA.ToString();
                }
                if (vlrSal > 1050 && vlrSal < 1400.77)
                {
                    descA = 0.09 * vlrSal;
                    txtAinss.Text = "9%";
                    txtDinss.Text = descA.ToString();
                }
                if (vlrSal > 1400.77&&vlrSal < 2801.56)
                {
                    descA = 0.11 * vlrSal;
                    txtAinss.Text = "11%";
                    txtDinss.Text = descA.ToString();
                }
                if (vlrSal>2801.56)
                {
                    txtAinss.Text = "Teto";
                    descA = 308.17;
                    txtDinss.Text = descA.ToString("N2");
                }

                if (vlrSal < 1257.12)
                {
                    descB = 0;
                    txtAirrf.Text = "Não paga";
                    txtDirrf.Text = descB.ToString();
                }
                else
                {
                    if (vlrSal < 2512.08)
                    {
                        descB = 0.15 * vlrSal;
                        txtAirrf.Text = "15%";
                        txtDirrf.Text = descB.ToString();

                    }
                    else
                    {
                        descB = vlrSal * 0.275;
                        txtAirrf.Text = "27,5%";
                        txtDirrf.Text = descB.ToString();
                    }
                }
                if (!double.TryParse(nupFilhos.Text, out filho))
                {
                    MessageBox.Show("Valores invalidos");
                    nupFilhos.Focus();
                }
                else
                    if (vlrSal < 435.52)
                {
                    l = filho * 22.33;
                    txtSalF.Text = l.ToString();
                }
                else
                {
                    if (vlrSal < 654.61)
                    {
                        l = filho * 15.74;
                        txtSalF.Text = l.ToString();
                    }
                    else
                    {
                        l = 0;
                        txtSalF.Text = l.ToString();
                    }
                }
                vlrSalL = vlrSal - descB - descA+l;
                txtSalL.Text = vlrSalL.ToString();
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((Char.IsNumber(e.KeyChar)) || (Char.IsPunctuation(e.KeyChar)))
            {
                MessageBox.Show("Caracter inválido");
                SendKeys.Send("{BACKSPACE}");
            }
        }
    }
}