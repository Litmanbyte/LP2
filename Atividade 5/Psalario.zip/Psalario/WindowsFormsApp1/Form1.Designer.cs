﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblLiq = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.lblNum = new System.Windows.Forms.Label();
            this.lblAli = new System.Windows.Forms.Label();
            this.lblSalF = new System.Windows.Forms.Label();
            this.lblIrff = new System.Windows.Forms.Label();
            this.lblDesc = new System.Windows.Forms.Label();
            this.lblirrf = new System.Windows.Forms.Label();
            this.btnVal = new System.Windows.Forms.Button();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.mskbxSal = new System.Windows.Forms.MaskedTextBox();
            this.nupFilhos = new System.Windows.Forms.NumericUpDown();
            this.txtDinss = new System.Windows.Forms.TextBox();
            this.txtSalL = new System.Windows.Forms.TextBox();
            this.txtSalF = new System.Windows.Forms.TextBox();
            this.txtAirrf = new System.Windows.Forms.TextBox();
            this.txtAinss = new System.Windows.Forms.TextBox();
            this.txtDirrf = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nupFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(53, 39);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(90, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário";
            // 
            // lblLiq
            // 
            this.lblLiq.AutoSize = true;
            this.lblLiq.Location = new System.Drawing.Point(53, 403);
            this.lblLiq.Name = "lblLiq";
            this.lblLiq.Size = new System.Drawing.Size(72, 13);
            this.lblLiq.TabIndex = 1;
            this.lblLiq.Text = "Salário liquido";
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.Location = new System.Drawing.Point(53, 71);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(39, 13);
            this.lblSal.TabIndex = 3;
            this.lblSal.Text = "Salário";
            // 
            // lblNum
            // 
            this.lblNum.AutoSize = true;
            this.lblNum.Location = new System.Drawing.Point(53, 104);
            this.lblNum.Name = "lblNum";
            this.lblNum.Size = new System.Drawing.Size(86, 13);
            this.lblNum.TabIndex = 5;
            this.lblNum.Text = "Número de filhos";
            // 
            // lblAli
            // 
            this.lblAli.AutoSize = true;
            this.lblAli.Location = new System.Drawing.Point(53, 268);
            this.lblAli.Name = "lblAli";
            this.lblAli.Size = new System.Drawing.Size(75, 13);
            this.lblAli.TabIndex = 7;
            this.lblAli.Text = "Alíquota INSS";
            // 
            // lblSalF
            // 
            this.lblSalF.AutoSize = true;
            this.lblSalF.Location = new System.Drawing.Point(53, 360);
            this.lblSalF.Name = "lblSalF";
            this.lblSalF.Size = new System.Drawing.Size(75, 13);
            this.lblSalF.TabIndex = 9;
            this.lblSalF.Text = "Salário famlília";
            // 
            // lblIrff
            // 
            this.lblIrff.AutoSize = true;
            this.lblIrff.Location = new System.Drawing.Point(483, 313);
            this.lblIrff.Name = "lblIrff";
            this.lblIrff.Size = new System.Drawing.Size(79, 13);
            this.lblIrff.TabIndex = 11;
            this.lblIrff.Text = "Desconto IRFF";
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.Location = new System.Drawing.Point(483, 268);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(81, 13);
            this.lblDesc.TabIndex = 13;
            this.lblDesc.Text = "Desconto INSS";
            // 
            // lblirrf
            // 
            this.lblirrf.AutoSize = true;
            this.lblirrf.Location = new System.Drawing.Point(53, 313);
            this.lblirrf.Name = "lblirrf";
            this.lblirrf.Size = new System.Drawing.Size(75, 13);
            this.lblirrf.TabIndex = 15;
            this.lblirrf.Text = "Alíquota IRRF";
            // 
            // btnVal
            // 
            this.btnVal.Location = new System.Drawing.Point(147, 177);
            this.btnVal.Name = "btnVal";
            this.btnVal.Size = new System.Drawing.Size(104, 23);
            this.btnVal.TabIndex = 16;
            this.btnVal.Text = "validar dados";
            this.btnVal.UseVisualStyleBackColor = true;
            this.btnVal.Click += new System.EventHandler(this.btnVal_Click);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(191, 36);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 17;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            // 
            // mskbxSal
            // 
            this.mskbxSal.Location = new System.Drawing.Point(191, 71);
            this.mskbxSal.Mask = "990000.00";
            this.mskbxSal.Name = "mskbxSal";
            this.mskbxSal.Size = new System.Drawing.Size(100, 20);
            this.mskbxSal.TabIndex = 18;
            // 
            // nupFilhos
            // 
            this.nupFilhos.Location = new System.Drawing.Point(191, 104);
            this.nupFilhos.Name = "nupFilhos";
            this.nupFilhos.Size = new System.Drawing.Size(120, 20);
            this.nupFilhos.TabIndex = 19;
            // 
            // txtDinss
            // 
            this.txtDinss.Enabled = false;
            this.txtDinss.Location = new System.Drawing.Point(595, 268);
            this.txtDinss.Name = "txtDinss";
            this.txtDinss.Size = new System.Drawing.Size(100, 20);
            this.txtDinss.TabIndex = 20;
            // 
            // txtSalL
            // 
            this.txtSalL.Enabled = false;
            this.txtSalL.Location = new System.Drawing.Point(164, 396);
            this.txtSalL.Name = "txtSalL";
            this.txtSalL.Size = new System.Drawing.Size(100, 20);
            this.txtSalL.TabIndex = 22;
            // 
            // txtSalF
            // 
            this.txtSalF.Enabled = false;
            this.txtSalF.Location = new System.Drawing.Point(164, 353);
            this.txtSalF.Name = "txtSalF";
            this.txtSalF.Size = new System.Drawing.Size(100, 20);
            this.txtSalF.TabIndex = 24;
            // 
            // txtAirrf
            // 
            this.txtAirrf.Enabled = false;
            this.txtAirrf.Location = new System.Drawing.Point(164, 306);
            this.txtAirrf.Name = "txtAirrf";
            this.txtAirrf.Size = new System.Drawing.Size(100, 20);
            this.txtAirrf.TabIndex = 26;
            // 
            // txtAinss
            // 
            this.txtAinss.Enabled = false;
            this.txtAinss.Location = new System.Drawing.Point(164, 261);
            this.txtAinss.Name = "txtAinss";
            this.txtAinss.Size = new System.Drawing.Size(100, 20);
            this.txtAinss.TabIndex = 28;
            // 
            // txtDirrf
            // 
            this.txtDirrf.Enabled = false;
            this.txtDirrf.Location = new System.Drawing.Point(595, 306);
            this.txtDirrf.Name = "txtDirrf";
            this.txtDirrf.Size = new System.Drawing.Size(100, 20);
            this.txtDirrf.TabIndex = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtDirrf);
            this.Controls.Add(this.txtAinss);
            this.Controls.Add(this.txtAirrf);
            this.Controls.Add(this.txtSalF);
            this.Controls.Add(this.txtSalL);
            this.Controls.Add(this.txtDinss);
            this.Controls.Add(this.nupFilhos);
            this.Controls.Add(this.mskbxSal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.btnVal);
            this.Controls.Add(this.lblirrf);
            this.Controls.Add(this.lblDesc);
            this.Controls.Add(this.lblIrff);
            this.Controls.Add(this.lblSalF);
            this.Controls.Add(this.lblAli);
            this.Controls.Add(this.lblNum);
            this.Controls.Add(this.lblSal);
            this.Controls.Add(this.lblLiq);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nupFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblLiq;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Label lblNum;
        private System.Windows.Forms.Label lblAli;
        private System.Windows.Forms.Label lblSalF;
        private System.Windows.Forms.Label lblIrff;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.Label lblirrf;
        private System.Windows.Forms.Button btnVal;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.MaskedTextBox mskbxSal;
        private System.Windows.Forms.NumericUpDown nupFilhos;
        private System.Windows.Forms.TextBox txtDinss;
        private System.Windows.Forms.TextBox txtSalL;
        private System.Windows.Forms.TextBox txtSalF;
        private System.Windows.Forms.TextBox txtAirrf;
        private System.Windows.Forms.TextBox txtAinss;
        private System.Windows.Forms.TextBox txtDirrf;
    }
}

