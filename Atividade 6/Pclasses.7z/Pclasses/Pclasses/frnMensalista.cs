﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frnMensalista : Form
    {
        public frnMensalista()
        {
            InitializeComponent();
        }
        private void frnMensalista_Load(object sender, EventArgs e)
        {
        }
            private void button2_Click(object sender, EventArgs e)
        {

            Mensalista objMensalista = new Mensalista();
            objMensalista.SalMensal = Convert.ToDouble(txtSal.Text);
            objMensalista.Matricula = Convert.ToInt32(txtMat.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objMensalista.NomeEmpregado = txtNo.Text;

            MessageBox.Show("Nome=" + objMensalista.NomeEmpregado + "\n" + "matricula=" + objMensalista.Matricula + "\n" + "Tempo trabalho :" + objMensalista.TempoTrabalho() + "\n" + "Salario final=" + objMensalista.SalarioBruto().ToString("N2"));
            MessageBox.Show(Mensalista.Empresa);
            MessageBox.Show(Mensalista.Filial);
        }
        private void button3_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(Convert.ToInt32(txtMat.Text), txtNo.Text, Convert.ToDateTime(txtData.Text), Convert.ToDouble(txtSal.Text));
            MessageBox.Show("Nome=" + objMensalista.NomeEmpregado + "\n" + "matricula=" + objMensalista.Matricula + "\n" + "Tempo trabalho :" + objMensalista.TempoTrabalho() + "\n" + "Salario final=" + objMensalista.SalarioBruto().ToString("N2"));

        }
    }
}
