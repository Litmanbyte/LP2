﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();
            objHorista.SalarioHora = Convert.ToDouble(txtSal.Text);
            objHorista.Matricula = Convert.ToInt32(txtMat.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.NomeEmpregado = txtNo.Text;
            objHorista.DiasFalta = Convert.ToInt32(txtFaltas.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHoras);

            MessageBox.Show("Nome=" + objHorista.NomeEmpregado + "\n" + "matricula=" + objHorista.Matricula + "\n" + "Tempo trabalho :" + objHorista.TempoTrabalho() + "\n" + "Salario final=" + objHorista.SalarioBruto().ToString("N2"));

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
