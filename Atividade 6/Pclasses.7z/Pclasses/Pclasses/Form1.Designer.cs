﻿namespace Pclasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMen = new System.Windows.Forms.Button();
            this.btnHor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMen
            // 
            this.btnMen.Location = new System.Drawing.Point(444, 115);
            this.btnMen.Name = "btnMen";
            this.btnMen.Size = new System.Drawing.Size(75, 23);
            this.btnMen.TabIndex = 0;
            this.btnMen.Text = "Mensalista ";
            this.btnMen.UseVisualStyleBackColor = true;
            this.btnMen.Click += new System.EventHandler(this.btnMen_Click);
            // 
            // btnHor
            // 
            this.btnHor.Location = new System.Drawing.Point(231, 114);
            this.btnHor.Name = "btnHor";
            this.btnHor.Size = new System.Drawing.Size(75, 23);
            this.btnHor.TabIndex = 1;
            this.btnHor.Text = "Horista";
            this.btnHor.UseVisualStyleBackColor = true;
            this.btnHor.Click += new System.EventHandler(this.btnHor_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnHor);
            this.Controls.Add(this.btnMen);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMen;
        private System.Windows.Forms.Button btnHor;
    }
}

