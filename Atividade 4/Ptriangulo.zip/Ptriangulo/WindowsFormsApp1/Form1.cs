﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void BtnLimp_Click(object sender, EventArgs e)
        {
            textBoxA.Text = "";
            textBoxB.Text = "";
            textBoxC.Text = "";
            textBoxR.Text = "";
            textBoxA.Focus();

        }
        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void BtnCalc_Click(object sender, EventArgs e)
        {
            double A, B,C;
            if ((!double.TryParse(textBoxA.Text, out A)) ||
                (!double.TryParse(textBoxB.Text, out B))||
                (!double.TryParse(textBoxC.Text, out C)))
            {
                MessageBox.Show("Valores invalidos");
                textBoxA.Focus();
            }
            else if ((A<=0||B<=0)||C<=0)
            {
                MessageBox.Show("Valores invalidos");
                textBoxA.Focus();
            }
            else if ((A>B+C)||(A < Math.Abs(B - C)))
            {
                MessageBox.Show("Valores invalidos");
                textBoxA.Focus();
            }
            else if ((B > A + C)||(B < Math.Abs(A-C)))
            {
                MessageBox.Show("Valores invalidos");
                textBoxA.Focus();
            }
            else if ((C > B + A)||(C < Math.Abs(A-B))) 
            {
                MessageBox.Show("Valores invalidos");
                textBoxA.Focus();
            }
            else if ((A != B && B!=C )&&C!=A)
            {
                textBoxR.Text="Escaleno";
            }
            else if ((A!=B)|(A!=C)&&B!=C)
            {
                textBoxR.Text = "Isóceles";
            }
            else if ((A==B&&A==C)&&(B==C))
            {
                textBoxR.Text = "Equilátero";
            }
        }

    }
}
