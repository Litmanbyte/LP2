﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace volume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblraio_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            double vlrRaio;
            if (!double.TryParse(textBox2.Text, out vlrRaio))
                MessageBox.Show("Raio invalido");
            else 
                if (vlrRaio <= 0)
                MessageBox.Show("Não existe raio negativo");
        }

        private void textBox3_Validated(object sender, EventArgs e)
        {
            double vlrH;
            if (!double.TryParse(textBox3.Text, out vlrH))
                MessageBox.Show("Altura invalida");
            else
                if (vlrH <= 0)
                MessageBox.Show("Não existe altura negativa");
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            double vlrRaio, vlrH;
            if ((!double.TryParse(textBox2.Text,out vlrRaio)) ||
                (!double.TryParse(textBox3.Text,out vlrH)))
            {
                MessageBox.Show("Valores invalidos");
                textBox2.Focus();
            }
            else 
                if (vlrRaio <= 0 || vlrH <= 0)
            {
                MessageBox.Show("Valores devem ser maiores que zero");
                textBox2.Focus();
            }
            else
            {
                double volume;
                volume = vlrRaio * vlrRaio * vlrH * Math.PI;
                textBox1.Text = volume.ToString("N2");
            }
        }

        private void btnfechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
