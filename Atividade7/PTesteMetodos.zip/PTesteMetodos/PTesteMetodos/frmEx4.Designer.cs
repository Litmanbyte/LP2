﻿namespace PTesteMetodos
{
    partial class frmEx4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtP1 = new System.Windows.Forms.TextBox();
            this.txtP2 = new System.Windows.Forms.TextBox();
            this.lblP1 = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.btnR = new System.Windows.Forms.Button();
            this.btnI = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtP1
            // 
            this.txtP1.Location = new System.Drawing.Point(243, 196);
            this.txtP1.Name = "txtP1";
            this.txtP1.Size = new System.Drawing.Size(120, 20);
            this.txtP1.TabIndex = 13;
            // 
            // txtP2
            // 
            this.txtP2.Location = new System.Drawing.Point(434, 196);
            this.txtP2.Name = "txtP2";
            this.txtP2.Size = new System.Drawing.Size(120, 20);
            this.txtP2.TabIndex = 12;
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.Location = new System.Drawing.Point(296, 163);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(13, 13);
            this.lblP1.TabIndex = 11;
            this.lblP1.Text = "1";
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.Location = new System.Drawing.Point(490, 163);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(13, 13);
            this.lblP2.TabIndex = 10;
            this.lblP2.Text = "2";
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(257, 251);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(95, 49);
            this.btnR.TabIndex = 9;
            this.btnR.Text = "remover 1 do 2";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // btnI
            // 
            this.btnI.Location = new System.Drawing.Point(450, 251);
            this.btnI.Name = "btnI";
            this.btnI.Size = new System.Drawing.Size(95, 49);
            this.btnI.TabIndex = 7;
            this.btnI.Text = "Inverte 1";
            this.btnI.UseVisualStyleBackColor = true;
            this.btnI.Click += new System.EventHandler(this.btnI_Click);
            // 
            // frmEx4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtP1);
            this.Controls.Add(this.txtP2);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnI);
            this.Name = "frmEx4";
            this.Text = "frmEx4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtP1;
        private System.Windows.Forms.TextBox txtP2;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnI;
    }
}