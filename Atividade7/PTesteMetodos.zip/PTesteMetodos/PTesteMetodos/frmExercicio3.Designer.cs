﻿namespace PTesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btnComp = new System.Windows.Forms.Button();
            this.lblP2 = new System.Windows.Forms.Label();
            this.lblP1 = new System.Windows.Forms.Label();
            this.txtP2 = new System.Windows.Forms.TextBox();
            this.txtP1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(356, 131);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(95, 49);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(556, 131);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(95, 49);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btnComp
            // 
            this.btnComp.Location = new System.Drawing.Point(178, 131);
            this.btnComp.Name = "btnComp";
            this.btnComp.Size = new System.Drawing.Size(95, 49);
            this.btnComp.TabIndex = 2;
            this.btnComp.Text = "comp";
            this.btnComp.UseVisualStyleBackColor = true;
            this.btnComp.Click += new System.EventHandler(this.btnComp_Click);
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.Location = new System.Drawing.Point(504, 56);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(13, 13);
            this.lblP2.TabIndex = 3;
            this.lblP2.Text = "2";
            this.lblP2.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.Location = new System.Drawing.Point(306, 56);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(13, 13);
            this.lblP1.TabIndex = 4;
            this.lblP1.Text = "1";
            this.lblP1.Click += new System.EventHandler(this.lblP1_Click);
            // 
            // txtP2
            // 
            this.txtP2.Location = new System.Drawing.Point(448, 89);
            this.txtP2.Name = "txtP2";
            this.txtP2.Size = new System.Drawing.Size(120, 20);
            this.txtP2.TabIndex = 5;
            // 
            // txtP1
            // 
            this.txtP1.Location = new System.Drawing.Point(257, 89);
            this.txtP1.Name = "txtP1";
            this.txtP1.Size = new System.Drawing.Size(120, 20);
            this.txtP1.TabIndex = 6;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtP1);
            this.Controls.Add(this.txtP2);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.btnComp);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btnComp;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.TextBox txtP2;
        private System.Windows.Forms.TextBox txtP1;
    }
}