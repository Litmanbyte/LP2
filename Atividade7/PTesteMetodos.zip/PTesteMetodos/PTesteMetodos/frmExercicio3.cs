﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblP1_Click(object sender, EventArgs e)
        {

        }

        private void btnComp_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtP1.Text,txtP2.Text,true) == 0)
            {
                MessageBox.Show("Iguais");
            }
            else
            {
                MessageBox.Show("Diferentes");
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            int meio = txtP2.Text.Length / 2;
            txtP2.Text= txtP2.Text.Substring(0,meio)+txtP1.Text + txtP2.Text.Substring(meio,txtP2.TextLength-meio);
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            int meio = txtP1.Text.Length / 2;
            txtP2.Text = txtP1.Text.Insert(meio, "**");
        }
    }
}
