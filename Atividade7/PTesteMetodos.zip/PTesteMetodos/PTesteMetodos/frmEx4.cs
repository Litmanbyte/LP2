﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmEx4 : Form
    {
        public frmEx4()
        {
            InitializeComponent();
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            txtP1.Text = txtP1.Text.ToLower();
            txtP1.Text = txtP1.Text.ToUpper();
            txtP2.Text = txtP2.Text.Replace(txtP1.Text, "");
        }

        private void btnI_Click(object sender, EventArgs e)
        {
            char[] vet = txtP1.Text.ToCharArray();  
            Array.Reverse(vet);
            txtP2.Text= new string(vet);
        }
    }
}
