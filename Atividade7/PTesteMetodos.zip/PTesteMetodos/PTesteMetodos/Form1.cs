﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {

                Application.OpenForms["frmExercicio3"].BringToFront();
            }
            else
            {
                frmExercicio3 obj3 = new frmExercicio3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();

            }
        }
            private void Ex4ToolStripMenuItem_click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx4>().Count()>0)
            {

                Application.OpenForms["frmEx4"].BringToFront();
            }
            else
            {
                frmEx4 obj4 = new frmEx4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();

            }
        }
        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Menu copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Menu colar");
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEx2 objfrm = new frmEx2();
            objfrm.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx5>().Count() > 0)
            {

                Application.OpenForms["frmEx5"].BringToFront();
            }
            else
            {
                frmEx5 obj5 = new frmEx5();
                obj5.MdiParent = this;
                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();

            }
        }
        private void exercicio6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmE6>().Count() > 0)
            {

                Application.OpenForms["frmE6"].BringToFront();
            }
            else
            {
                frmE6 obj6 = new frmE6();
                obj6.MdiParent = this;
                obj6.WindowState = FormWindowState.Maximized;
                obj6.Show();

            }
        }
    }
}
