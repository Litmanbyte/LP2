﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
          
            this.IsMdiContainer = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vet = new int[20];
            String aux;
            for (int i = 0; i < vet.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1}º número", "Entrada de dados");
                if (!int.TryParse(aux, out vet[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }
            Array.Reverse(vet);
            aux = "";
            foreach (int i in vet)
            {
                aux += i + "\n";
            }
            MessageBox.Show(aux);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String aux = "";
            ArrayList vet = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            vet.Remove("Otávio");
            foreach (string aluno in vet)
            {
                aux += aluno + "\n";
            }
            MessageBox.Show(aux);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String aux;
            double[,] reg = new double[20, 3];
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite a nota", "Digite o aluno");
                    if (!double.TryParse(aux, out reg[i, j]) || reg[i, j] < 0 || reg[i, j] > 10)
                    {
                        
                        MessageBox.Show("Número inválido!");
                        
                        j--;
                    }


                }
            }
            double soma = 0;
            double[] media = new double[3];
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    soma += reg[i, j];
                }
                media[i] = soma / 3;
                soma = 0;
                aux = "";
                aux += $"Aluno {i+1}, média :{media[i].ToString("F2")}";
                MessageBox.Show(aux);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Ex4 Ex4 = new Ex4();
            Ex4.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            String aux;            
            Char[] vet = { 'A', 'A', 'B', 'C', 'D', 'D', 'E', 'E', 'D', 'D' };
            char[,] reg = new char[6, 10];
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    aux = Interaction.InputBox($"Digite a resposta");
                    if (!char.TryParse(aux, out reg[i, j]) || reg[i, j] > 'E' || reg[i, j] <'A' )
                    {

                        MessageBox.Show("Alternativa inválida!");

                        j--;
                    }


                }
            }
            int soma = 0;
            int[] media = new int[6];
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (reg[i, j] == vet[j] )
                    soma++;
                }
                media[i] = soma;
                soma = 0;
                aux = "";
                aux += $"Aluno {i + 1}, média :{media[i].ToString("F2")}";
                listBox1.Items.Add(aux);
            }
        }
    }
}
