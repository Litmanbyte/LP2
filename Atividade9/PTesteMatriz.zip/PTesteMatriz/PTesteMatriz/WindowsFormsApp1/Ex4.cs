﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Ex4 : Form
    {
        public Ex4()
        {
           
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[5];
            for (int i = 0; i < 5; i++)
            {
                string nome = Interaction.InputBox("Digite o nome " + (i + 1) + ":", "Digite o nome");
                if (!string.IsNullOrEmpty(nome))
                    nomes[i] = nome;
                else
                {
                    MessageBox.Show("Por favor, digite um nome válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            SetNomes(nomes);
        }

        public void SetNomes(string[] nomes)
        {
            foreach (string nome in nomes)
            {
                int numCaracteres = nome.Replace(" ", "").Length;
                listBox1.Items.Add("O nome: " + nome + ", número de caracteres: " + numCaracteres);
            }
        }
    }
}
