﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void textNum1_Validated(object sender, EventArgs e)
        {
            double A;
            if (!double.TryParse(textNum1.Text, out A))
                MessageBox.Show("Invalido");

        }
        private void textNum2_Validated(object sender, EventArgs e)
        {
            double B;
            if (!double.TryParse(textNum2.Text, out B))
                MessageBox.Show("Invalido");

        }
        private void btnMais_Click(object sender, EventArgs e)
        {
            double A, B;
            if ((!double.TryParse(textNum1.Text, out A)) ||
                (!double.TryParse(textNum2.Text, out B)))
            {
                MessageBox.Show("Valores invalidos");
                textNum1.Focus();
            }

            else
            {
                double x;
                x = A + B;
                textResult.Text = x.ToString("N2");
            }
        }
        private void btnMenos_Click(object sender, EventArgs e)
        {
            double A, B;
            if ((!double.TryParse(textNum1.Text, out A)) ||
                (!double.TryParse(textNum2.Text, out B)))
            {
                MessageBox.Show("Valores invalidos");
                textNum1.Focus();
            }

            else
            {
                double x;
                x = A - B;
                textResult.Text = x.ToString("N2");
            }
        }
        private void btnMul_Click(object sender, EventArgs e)
        {
            double A, B;
            if ((!double.TryParse(textNum1.Text, out A)) ||
                (!double.TryParse(textNum2.Text, out B)))
            {
                MessageBox.Show("Valores invalidos");
                textNum1.Focus();
            }

            else
            {
                double x;
                x = A * B;
                textResult.Text = x.ToString("N2");
            }
        }
        private void btnDiv_Click(object sender, EventArgs e)
        {
            double A, B;
            if ((!double.TryParse(textNum1.Text, out A)) ||
                (!double.TryParse(textNum2.Text, out B)))
            {
                MessageBox.Show("Valores invalidos");
                textNum1.Focus();
            }
            else if (B == 0)
            {
                MessageBox.Show("Valor invalido");
            }
            else
            {
                double x;
                x = A / B;
                textResult.Text = x.ToString("N2");
            }
        }
        private void btnfechar_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            textNum1.Text = "";
            textNum2.Text = "";
            textResult.Text = "";
            textNum1.Focus();
            
        }
    }
}
