﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBoxA_Validated(object sender, EventArgs e)
        {
            double A;
            if (!double.TryParse(textBoxA.Text, out A))
                MessageBox.Show("Invalido");
            else if (A <= 0)
            {
                MessageBox.Show("Invalido");
            }

        }
        private void textBoxP_Validated(object sender, EventArgs e)
        {
            double P;
            if (!double.TryParse(textBoxP.Text, out P))
                MessageBox.Show("Invalido");
            else if (P <= 0)
            {
                MessageBox.Show("Invalido");
            }

        }
        private void btnCalc_Click(object sender, EventArgs e)
        {
            double A, P;
            if ((!double.TryParse(textBoxA.Text, out A)) ||
                (!double.TryParse(textBoxP.Text, out P)))
            {
                MessageBox.Show("Valores invalidos");
                textBoxA.Focus();
            }

            else
            {
                double x;
                x = P / Math.Pow(A, 2);
                x = Math.Round(x);
                if (x < 18.5)
                {
                    textBoxR.Text = "Magreza";
                }
                else if (x < 24.9)
                {
                    textBoxR.Text = "Normal";
                }
                else if (x < 29.9)
                { textBoxR.Text = "Sobrepeso"; }
                else if (x < 39.9)
                {
                    textBoxR.Text = "Obesidade";
                }
                else
                {
                    textBoxR.Text = "Obesidade morbida";
                }
            }
           
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            textBoxR.Text = "";
            textBoxP.Text = "";
            textBoxA.Text = "";
            textBoxA.Focus();
        }
    }
}
